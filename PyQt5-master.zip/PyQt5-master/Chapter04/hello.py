# -*- coding: utf-8 -*- 

def sayHello():
	str="hello"
	print('hello python');

if __name__ == "__main__":
	print ('This is main of module "hello.py"')
	sayHello()
	
	