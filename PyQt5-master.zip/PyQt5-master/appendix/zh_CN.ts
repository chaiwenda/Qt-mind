<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Winform</name>
    <message>
        <location filename="i18n01.py" line="16"/>
        <source>title</source>
        <translation type="unfinished">上传</translation>
    </message>
    <message>
        <location filename="i18n01.py" line="19"/>
        <source>upload</source>
        <translation type="unfinished">下载</translation>
    </message>
    <message>
        <location filename="i18n01.py" line="20"/>
        <source>download</source>
        <translation type="unfinished">国际化例子</translation>
    </message>
</context>
</TS>
